import { LayoutUsuario } from "@/components/LayoutUsuario";

export default function Usuario() {
    return (
        <LayoutUsuario>
            
        </LayoutUsuario>
    )
}
