import { LayoutDashboard } from "@/components/LayoutDashboard";

export default function Dashboard() {
    return (
        <LayoutDashboard>
            
        </LayoutDashboard>
    )
}